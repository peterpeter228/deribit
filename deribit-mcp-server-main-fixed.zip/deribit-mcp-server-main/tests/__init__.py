"""Tests for Deribit MCP Server."""
